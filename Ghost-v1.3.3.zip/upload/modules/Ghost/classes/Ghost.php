<?php
class Ghost {
   
    // Set correct timezone
    public static function setTimezone() {
  		$timezone = DB::getInstance()->get('settings', ['name', '=', 'timezone'])->results();
  		$timezone = $timezone[0]->value;
  		date_default_timezone_set($timezone);
    }

    // Purify post name (for post URL)
    public static function purifyPostName($name) {
        $url = preg_replace('~[^\\pL0-9_]+~u', '-', $name);
        $url = trim($url, "-");
        $url = iconv("utf-8", "us-ascii//TRANSLIT", $url);
        $url = strtolower($url);
        $url = preg_replace('~[^-a-z0-9_]+~', '', $url);
        return $url;
    }

    // Trim post content to 250 characters cleanly
    public static function purifyPostContent($content) {
        $content = Output::getPurified(Output::getDecoded($content));
        $content = strip_tags($content, '<br>');
        $content = preg_replace('/^(<br\s*\/?>)*|(<br\s*\/?>)*$/i', '', $content);
        $content = preg_replace("/<br\W*?\/>/", "➍", $content);
        //$content = Util::truncate($content, '250', array('exact' => false, 'html' => true));
        $content = Text::truncate($content, '250', array('exact' => false, 'html' => true));
        $content = preg_replace("/➍/", "<br/>", $content);
        return $content;
    }

    // Allow uploading images
    public static function uploadImage()  {

        $target_path = ROOT_PATH . '/uploads/ghost-' . basename($_FILES['ghost_post_image']['name']);
        $img_url = (defined('CONFIG_PATH') ? CONFIG_PATH : '') . 'uploads/ghost-' . basename($_FILES['ghost_post_image']['name']);
    
        $file_parts = pathinfo($target_path);
    
        if ($file_parts['extension'] !== 'png' && $file_parts['extension'] !== 'jpg' && $file_parts['extension'] !== 'jpeg') {
            $errors[] = 'Error with image filetype. Please make sure you upload a png, jpg, or jpeg.';
            $cf_errors = 'yes';
        }
        
        if(move_uploaded_file($_FILES['ghost_post_image']['tmp_name'], $target_path)) {
            //success
        } else{
            $errors[] = 'Error with image moving process. Please try again, and if the error persists, contact Coldfire Design support.';
            $cf_errors = 'yes';
        }
    
        if (!$cf_errors) {
            $dir = ROOT_PATH . '/uploads/ghost-';
            $name = $_FILES['ghost_post_image']['name'];
            $newName = bin2hex(openssl_random_pseudo_bytes(5)) . $image . '.webp';
        
            if ($file_parts['extension'] == 'png') {
                $img = imagecreatefrompng($dir . $name);
            } elseif ($file_parts['extension'] == 'jpg' || $file_parts['extension'] == 'jpeg') {
                $img = imagecreatefromjpeg($dir . $name);
            }
        
            imagepalettetotruecolor($img);
            imagealphablending($img, true);
            imagesavealpha($img, true);
            imagewebp($img, $dir . $newName, 80);
            imagedestroy($img);

            // delete jpg/png and just leave webp
            unlink($target_path);

            $full_image_url = (defined('CONFIG_PATH') ? CONFIG_PATH : '') . '/uploads/ghost-' . $newName;

            return $full_image_url;
        } else {
            return $errors;
        }

    }

}
?>