<?php
/*
 *	Ghost module made by Coldfire
 *	https://coldfiredzn.com
 *
 */
 
define('PAGE', 'ghost');

// Ghost class
require_once(ROOT_PATH . '/modules/Ghost/classes/Ghost.php');
$ghost = new Ghost();

// Page query string checker
$filtered_url = end(explode('/post/', $_SERVER['REQUEST_URI']));
if (str_contains($filtered_url, '-')) {
    $filtered_url = substr($filtered_url, 0, strpos($filtered_url, '-'));
}

// Get post
$post = DB::getInstance()->get("ghost_posts", ["id", "=", $filtered_url])->results();
$post = $post[0];

// No fatal error if no post exists
if (empty($post)) {
    require_once(ROOT_PATH . '/404.php');
    die();
}

$page_title = $post->name;
require_once(ROOT_PATH . '/core/templates/frontend_init.php');

// Timezone
Ghost::setTimezone();

// Purify post content
$post_content_filtered = strip_tags(Output::getDecoded($post->content));
$post_content_filtered = Text::truncate($post_content_filtered, '250', ['exact' => true, 'html' => true]);

// Get Tags
$ghost_tags = DB::getInstance()->get('ghost_tags', ['id', '<>', 0])->results();
$tags_array = [];
	
// Generate Tag Array for Each Post
$enabled_tags = explode(',', $post->post_tags);
if(count($enabled_tags)) {
	$tag_names = [];
	foreach($enabled_tags as $tag) {
		foreach($ghost_tags as $list_tag){
			if ($list_tag->id == $tag)  {
				$tag_names[$list_tag->name] = $list_tag->color;
			}
		}
	}
} else {
	$tag_names = null;
}

$post_author = new User($post->author);
if ($post->date < time()) {
    $template->getEngine()->addVariables([
        'post_name' => $post->name,
        'post_date' => date("M jS\, Y", Output::getClean($post->date)),
        'post_author' => $post_author->getDisplayname(),
        'post_readtime' => str_replace("{x}", $post->readtime, $ghost_language->get('ghost', 'minute_read')),
        'post_image' => Output::getClean($post->image),
        'post_content' => Output::getDecoded($post->content),
        'post_content_filtered' => $post_content_filtered,
        'post_avatar' => $post_author->getAvatar('40'),
        'post_author_styles' => $post_author->getGroupStyle(),
        'post_author_profile' => $post_author->getProfileURL(),
        'post_author_groups' => $post_author->getMainGroup()->group_html,
        'post_tags' => $tag_names
    ]);
} else {
    require_once(ROOT_PATH . '/404.php');
    die();
}

// View Counter
if ($user->isLoggedIn() || (defined('COOKIE_CHECK') && COOKIES_ALLOWED)) {
    if (!Cookie::exists('post-' . $post->id)) {
        DB::getInstance()->increment('ghost_posts', $post->id, 'views');
        Cookie::put('post-' . $post->id, 'true', 3600);
    }
} else {
    if (!Session::exists('post-' . $post->id)) {
        DB::getInstance()->increment('ghost_posts', $post->id, 'views');
        Session::put('post-' . $post->id, 'true');
    }
}

// Extra posts
$posts = DB::getInstance()->query("SELECT * FROM `nl2_ghost_posts` WHERE id NOT IN ('" . $post->id . "') AND date < " . time() . " ORDER BY date DESC LIMIT 3")->results();
$posts_array = [];

foreach($posts as $post){

    // Generate Tag Array for Each Post
    $enabled_tags = explode(',', $post->post_tags);
    if(count($enabled_tags)) {
	    $tag_names = [];
	    foreach($enabled_tags as $tag) {
		    foreach($ghost_tags as $list_tag){
			    if ($list_tag->id == $tag)  {
			    	$tag_names[$list_tag->name] = $list_tag->color;
			    }
		    }
	    }
    } else {
	    $tag_names = null;
    }

    $post_author = new User($post->author);

    $posts_array[] = [
        'name' => $post->name,
		'date' => date("M jS\, Y", Output::getClean($post->date)),
		'author' => $post_author->getDisplayname(),
		'readtime' => str_replace("{x}", $post->readtime, $ghost_language->get('ghost', 'minute_read')),
		'image' => Output::getClean($post->image),
		'content' => Ghost::purifyPostContent($post->content),
		'avatar' => $post_author->getAvatar('40'),
		'author_styles' => $post_author->getGroupStyle(),
	    'author_profile' => $post_author->getProfileURL(),
		'author_groups' => $post_author->getMainGroup()->group_html,
        'link' => URL::build('/post/' . $post->id . '-' . Ghost::purifyPostName($post->name)),
		'card_size' => 'post-card-small',
        'post_tags' => $tag_names
    ];
}

$template->getEngine()->addVariables([
    'GHOST_POSTS' => $posts_array,
    'MORE_POSTS' => $ghost_language->get('ghost', 'more_posts')
]);

Module::loadPage($user, $pages, $cache, $smarty, [$navigation, $cc_nav, $staffcp_nav], $widgets, $template);

$template->onPageLoad();

require(ROOT_PATH . '/core/templates/navbar.php');
require(ROOT_PATH . '/core/templates/footer.php');
	
$template->displayTemplate('ghost/post');

/*  
 *  DeCrys
 *  22772
 *  205534
 *  1758037333
 *  %%__FILEHASH__%%
 *  cd8cd24ec07cdddd5083d17992f2df87
 */