<?php 
/*
 *	Ghost module made by Coldfire
 *	https://coldfiredzn.com
 *
 */
 
if(!$user->handlePanelPageLoad('admincp.ghost')) {
    require_once(ROOT_PATH . '/403.php');
    die();
}

define('PAGE', 'panel');
define('PARENT_PAGE', 'ghost');
define('PANEL_PAGE', 'ghost');
$page_title = $ghost_language->get('ghost', 'ghost');
require_once(ROOT_PATH . '/core/templates/backend_init.php');

// Readtime
function estimated_read_time($content) {
    $clean_content = strip_tags($content);
    $word_count = str_word_count($clean_content);
    $time = ceil($word_count / 250);
    return $time;
}

if(!isset($_GET['action'])){


 	// Page Query String Checker
	if(strpos($_SERVER['QUERY_STRING'], 'p=') !== false){
		$page_id = strstr($_SERVER['QUERY_STRING'], 'p=');
    	$page_id = preg_replace("/[^0-9]/", "", $_SERVER['QUERY_STRING']);
		if (!$page_id) {
			$page_id = 1;
		}
	} else {
		$page_id = 1;
	}
	
  	$offset = ($page_id * 6) - 6;

	// Get posts
	$ghost_posts = DB::getInstance()->query("SELECT * FROM `nl2_ghost_posts` ORDER BY date DESC LIMIT 6 OFFSET " . $offset)->results();
	$posts_array = [];

	// Redirect to home if no posts
	if (empty($ghost_posts) && $page_id != 1) {
		Redirect::to(URL::build('/panel/ghost'));
	}

	// Pagination
	$paginator = new Paginator(($template_pagination ?? []));
	$paginator_posts = DB::getInstance()->query("SELECT id FROM `nl2_ghost_posts` ORDER BY date DESC")->results();
	$results = $paginator->getLimited($paginator_posts, 6, $page_id, count($paginator_posts));
	$pagination = $paginator->generate(5);
	$template->getEngine()->addVariable('PAGINATION', $pagination);

	// Timezone
	Ghost::setTimezone();

	// Get Tags
	$ghost_tags = DB::getInstance()->get('ghost_tags', ['id', '<>', 0])->results();
	$tags_array = [];
	
	if(count($ghost_tags)){
		foreach($ghost_tags as $tag){
			$tags_array[] = [
				'edit_link' => URL::build('/panel/ghost/', 'action=edit_tag&id=' . Output::getClean($tag->id)),
				'name' => $tag->name,
				'color' => $tag->color,
				'delete_link' => URL::build('/panel/ghost/', 'action=delete_tag&id=' . Output::getClean($tag->id))
			];
		}
	}

	if(count($ghost_posts)){
		foreach($ghost_posts as $post){

			// Generate Tag Array for Each Post
			$enabled_tags = explode(',', $post->post_tags);
			if(count($enabled_tags)) {
				$tag_names = [];
				foreach($enabled_tags as $tag) {
					foreach($ghost_tags as $list_tag){
						if ($list_tag->id == $tag)  {
							$tag_names[$list_tag->name] = $list_tag->color;
						}
					}
				}
				//$tag_names = join(", ", $tag_names);
			} else {
				$tag_names = null;
			}
		    
  			// Set views to 0 if null
  			if (!$post->views) {
		        $post->views = 0;
		        DB::getInstance()->update('ghost_posts', $post->id, ['views' => 0]);
		    }

            if ($post->date < time()) {
                $published = "yes";
            } else {
                $published = "no";
            }

			$posts_array[] = [
				'edit_link' => URL::build('/panel/ghost/', 'action=edit&id=' . Output::getClean($post->id)),
				'duplicate_link' => URL::build('/panel/ghost/', 'action=duplicate&id=' . Output::getClean($post->id)),
				'name' => $post->name,
				'date' => date("M jS\, Y \- h:i A T", Output::getClean($post->date)),
				'views' => $post->views,
				'published' => $published,
				'delete_link' => URL::build('/panel/ghost/', 'action=delete&id=' . Output::getClean($post->id)),
				'view_link' => URL::build('/post/' . $post->id . '-' . Ghost::purifyPostName($post->name)),
				'tags' => $tag_names
			];
		}
	}

	$template->getEngine()->addVariables([
	    'VIEWS' => $ghost_language->get('ghost', 'views'),
		'NEW_POST' => $ghost_language->get('ghost', 'new_post'),
		'GHOST_POST_NAME' => $ghost_language->get('ghost', 'ghost_post_name'),
		'POST_TAGS' => $ghost_language->get('ghost', 'ghost_post_tags'),
		'POST_DATE' => $ghost_language->get('ghost', 'ghost_post_date'),
		'PUBLISHED' => $ghost_language->get('ghost', 'published'),
		'GHOST_ACTION' => $ghost_language->get('ghost', 'ghost_action'),
		'NEW_POST_LINK' => URL::build('/panel/ghost/', 'action=new'),
		'POST_LIST' => $posts_array,
		'NO_GHOST_POSTS' => $ghost_language->get('ghost', 'no_ghost_posts'),
		'ARE_YOU_SURE' => $language->get('general', 'are_you_sure'),
		'CONFIRM_DELETE_POST' => $ghost_language->get('ghost', 'delete_post'),
		'YES' => $language->get('general', 'yes'),
		'NO' => $language->get('general', 'no'),
		'NEW_TAG' => $ghost_language->get('ghost', 'new_tag'),
		'TAG_NAME' => $ghost_language->get('ghost', 'ghost_tag_name'),
		'TAG_COLOR' => $ghost_language->get('ghost', 'ghost_tag_color'),
		'NEW_TAG_LINK' => URL::build('/panel/ghost/', 'action=new_tag'),
		'TAG_LIST' => $tags_array,
		'NO_GHOST_TAGS' => $ghost_language->get('ghost', 'no_ghost_tags'),
		'CONFIRM_DELETE_TAG' => $ghost_language->get('ghost', 'delete_tag'),
	]);
	
	$template_file = 'ghost/ghost.tpl';
} else {
	switch($_GET['action']){
		case 'new':

			// Get tags
			$ghost_tags = DB::getInstance()->get('ghost_tags', ['id', '<>', 0])->results();
			$tags_array = [];

			if(count($ghost_tags)){
				foreach($ghost_tags as $tag){
					$tags_array[] = [
						'id' => $tag->id,
						'name' => $tag->name
					];
				}
			}

			if(Input::exists()){
				if(Token::check(Input::get('token'))){
					$validation = Validate::check($_POST, [
						'ghost_post_name' => [
							Validate::REQUIRED => true,
							Validate::MAX => 96
						],
						'ghost_post_date' => [Validate::REQUIRED => true],
						'ghost_post_content' => [Validate::REQUIRED => true]
					])->messages([
						'ghost_post_name' => [
							Validate::REQUIRED => $ghost_language->get('ghost', 'post_name_required'),
							Validate::MAX => $ghost_language->get('ghost', 'post_name_maximum')
						],
						'ghost_post_date' => $ghost_language->get('ghost', 'post_date_required'),
						'ghost_post_content' => $ghost_language->get('ghost', 'post_content_required')
					]);

					if($validation->passed()){
					
						$image_upload = Ghost::uploadImage();
						
						if (is_array($image_upload) == false) { // Ensure no errors

							$post_tags_string = '';
							if (isset($_POST['ghost_post_tags']) && count($_POST['ghost_post_tags'])) {
								// Turn array of inputted tags into string of tags
								foreach ($_POST['ghost_post_tags'] as $item) {
									$post_tags_string .= $item . ',';
								}
							}
							$post_tags_string = rtrim($post_tags_string, ',');

							try {
								DB::getInstance()->insert('ghost_posts', [
									'name' => htmlspecialchars(Input::get('ghost_post_name')),
									'date' => htmlspecialchars(strtotime(Input::get('ghost_post_date'))),
									'author' => $user->data()->id,
									'readtime' => htmlspecialchars(estimated_read_time(Input::get('ghost_post_content'))),
									'image' => $image_upload,
									'content' => htmlspecialchars(Input::get('ghost_post_content')),
									'post_summary' => htmlspecialchars(Input::get('ghost_post_summary')),
									'views' => 0,
									'post_tags' => $post_tags_string,
								]);
								Session::flash('staff_ghost', $ghost_language->get('ghost', 'post_created_successfully'));
								Redirect::to(URL::build('/panel/ghost'));
								die();
							} catch(Exception $e){
								$errors[] = $e->getMessage();
							}

						} else {
							foreach ($image_upload as $cf_error) { // Add errors to errors array
								$errors[] = $cf_error;
							}
						}
					}
 				
                    if (!empty($validation->errors())) {
					  $errors = $validation->errors();
 				    }

				} else {
					$errors[] = $language->get('general', 'invalid_token');
				}

				// Saves input if post validation fails
				$template->getEngine()->addVariables([
					'GHOST_POST_NAME_VALUE' => Input::get('ghost_post_name'),
					'GHOST_POST_DATE_VALUE' => Input::get('ghost_post_date'),
					'GHOST_POST_CONTENT_VALUE' => Input::get('ghost_post_content'),
					'GHOST_POST_SUMMARY_VALUE' => Input::get('ghost_post_summary')
				]);
			}
						
			$template->getEngine()->addVariables([
				'NEW_POST' => $ghost_language->get('ghost', 'new_post'),
				'BACK' => $language->get('general', 'back'),
				'BACK_LINK' => URL::build('/panel/ghost'),
				'GHOST_POST_NAME' => $ghost_language->get('ghost', 'ghost_post_name'),
				'GHOST_POST_DATE' => $ghost_language->get('ghost', 'ghost_post_date'),
				'GHOST_POST_IMAGE' => $ghost_language->get('ghost', 'ghost_post_image'),
				'GHOST_POST_CONTENT' => $ghost_language->get('ghost', 'ghost_post_content'),
				'GHOST_POST_SUMMARY' => $ghost_language->get('ghost', 'ghost_post_summary'),
				'GHOST_POST_SUMMARY_BLANK' => $ghost_language->get('ghost', 'ghost_post_summary_blank'),
				'GHOST_POST_TAGS' => $ghost_language->get('ghost', 'ghost_post_tags'),
				'GHOST_TAGS' => $tags_array,
			]);
			
			$template_file = 'ghost/post_new.tpl';
		break;
		case 'duplicate':

			if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$post = DB::getInstance()->get('ghost_posts', ['id', '=', $_GET['id']])->results();
			if(!count($post)){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$post = $post[0];


			// Get tags
			$ghost_tags = DB::getInstance()->get('ghost_tags', ['id', '<>', 0])->results();
			$tags_array = [];

			// Tags for the post
			$enabled_tags = explode(',', $post->post_tags);
			
			if(count($ghost_tags)){
				foreach($ghost_tags as $tag){
					$tags_array[] = [
						'id' => $tag->id,
						'name' => $tag->name,
						'selected' => (in_array($tag->id, $enabled_tags))
					];
				}
			}

			if(Input::exists()){
				if(Token::check(Input::get('token'))){
					$validation = Validate::check($_POST, [
						'ghost_post_name' => [
							Validate::REQUIRED => true,
							Validate::MAX => 96
						],
						'ghost_post_date' => [Validate::REQUIRED => true],
						'ghost_post_content' => [Validate::REQUIRED => true]
					])->messages([
						'ghost_post_name' => [
							Validate::REQUIRED => $ghost_language->get('ghost', 'post_name_required'),
							Validate::MAX => $ghost_language->get('ghost', 'post_name_maximum')
						],
						'ghost_post_date' => $ghost_language->get('ghost', 'post_date_required'),
						'ghost_post_content' => $ghost_language->get('ghost', 'post_content_required')
					]);

					if($validation->passed()){
						
						$image_upload = Ghost::uploadImage();
						
						if (is_array($image_upload) == false) { // Ensure no errors

							$post_tags_string = '';
							if (isset($_POST['ghost_post_tags']) && count($_POST['ghost_post_tags'])) {
								// Turn array of inputted forums into string of forums
								foreach ($_POST['ghost_post_tags'] as $item) {
									$post_tags_string .= $item . ',';
								}
							}
							$post_tags_string = rtrim($post_tags_string, ',');

							try {
								DB::getInstance()->insert('ghost_posts', [
									'name' => htmlspecialchars(Input::get('ghost_post_name')),
									'date' => htmlspecialchars(strtotime(Input::get('ghost_post_date'))),
									'author' => $user->data()->id,
									'readtime' => htmlspecialchars(estimated_read_time(Input::get('ghost_post_content'))),
									'image' => $image_upload,
									'content' => htmlspecialchars(Input::get('ghost_post_content')),
									'post_summary' => htmlspecialchars(Input::get('ghost_post_summary')),
									'views' => 0,
									'post_tags' => $post_tags_string,
								]);
								Session::flash('staff_ghost', $ghost_language->get('ghost', 'post_created_successfully'));
								Redirect::to(URL::build('/panel/ghost'));
								die();
							} catch(Exception $e){
								$errors[] = $e->getMessage();
							}

						} else {
							foreach ($image_upload as $cf_error) { // Add errors to errors array
								$errors[] = $cf_error;
							}
						}
					}
 				
                    if (!empty($validation->errors())) {
					  $errors = $validation->errors();
 				    }

				} else {
					$errors[] = $language->get('general', 'invalid_token');
				}

				// Saves input if post validation fails
				$template->getEngine()->addVariables([
					'GHOST_POST_NAME_VALUE' => Input::get('ghost_post_name'),
					'GHOST_POST_DATE_VALUE' => Input::get('ghost_post_date'),
					'GHOST_POST_CONTENT_VALUE' => Input::get('ghost_post_content'),
					'GHOST_POST_SUMMARY_VALUE' => Input::get('ghost_post_summary')
				]);
			}

			$template->getEngine()->addVariables([
				'NEW_POST' => $ghost_language->get('ghost', 'new_post'),
				'BACK' => $language->get('general', 'back'),
				'BACK_LINK' => URL::build('/panel/ghost'),
				'GHOST_POST_NAME' => $ghost_language->get('ghost', 'ghost_post_name'),
				'GHOST_POST_DATE' => $ghost_language->get('ghost', 'ghost_post_date'),
				'GHOST_POST_IMAGE' => $ghost_language->get('ghost', 'ghost_post_image'),
				'GHOST_DELETE_IMAGE' => $ghost_language->get('ghost', 'ghost_delete_image'),
				'GHOST_POST_CONTENT' => $ghost_language->get('ghost', 'ghost_post_content'),
				'GHOST_POST_SUMMARY' => $ghost_language->get('ghost', 'ghost_post_summary'),
				'GHOST_POST_TAGS' => $ghost_language->get('ghost', 'ghost_post_tags'),
				'GHOST_POST_SUMMARY_BLANK' => $ghost_language->get('ghost', 'ghost_post_summary_blank'),
				'GHOST_POST_NAME_VALUE' => $post->name,
				'GHOST_POST_CONTENT_VALUE' => $post->content,
				'GHOST_POST_SUMMARY_VALUE' => $post->post_summary,
				'GHOST_TAGS' => $tags_array
			]);
			
			$template_file = 'ghost/post_duplicate.tpl';
		break;
		case 'new_tag':

			if(Input::exists()){
				if(Token::check(Input::get('token'))){
					$validation = Validate::check($_POST, [
						'ghost_tag_name' => [
							Validate::REQUIRED => true,
							Validate::MAX => 96
						],
						'ghost_tag_color' => [Validate::REQUIRED => true]
					])->messages([
						'ghost_tag_name' => [
							Validate::REQUIRED => $ghost_language->get('ghost', 'tag_name_required'),
							Validate::MAX => $ghost_language->get('ghost', 'tag_name_maximum')
						],
						'ghost_tag_color' => $ghost_language->get('ghost', 'tag_color_required')
					]);

					if($validation->passed()){			

							try {
								DB::getInstance()->insert('ghost_tags', [
									'name' => htmlspecialchars(Input::get('ghost_tag_name')),
									'color' => htmlspecialchars(Input::get('ghost_tag_color'))
								]);
								Session::flash('staff_ghost', $ghost_language->get('ghost', 'tag_created_successfully'));
								Redirect::to(URL::build('/panel/ghost'));
								die();
							} catch(Exception $e){
								$errors[] = $e->getMessage();
							}

					}
 				
                    if (!empty($validation->errors())) {
					  $errors = $validation->errors();
 				    }

				} else {
					$errors[] = $language->get('general', 'invalid_token');
				}

				// Saves input if post validation fails
				$template->getEngine()->addVariables([
					'GHOST_TAG_NAME_VALUE' => Input::get('ghost_tag_name'),
					'GHOST_TAG_COLOR_VALUE' => Input::get('ghost_tag_color')
				]);
			}
						
			$template->getEngine()->addVariables([
				'NEW_POST' => $ghost_language->get('ghost', 'new_post'),
				'BACK' => $language->get('general', 'back'),
				'BACK_LINK' => URL::build('/panel/ghost'),
				'GHOST_TAG_NAME' => $ghost_language->get('ghost', 'ghost_tag_name'),
				'GHOST_TAG_COLOR' => $ghost_language->get('ghost', 'ghost_tag_color')
			]);
			
			$template_file = 'ghost/tag_new.tpl';
		break;
		case 'edit':

			if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$post = DB::getInstance()->get('ghost_posts', ['id', '=', $_GET['id']])->results();
			if(!count($post)){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$post = $post[0];


			// Get tags
			$ghost_tags = DB::getInstance()->get('ghost_tags', ['id', '<>', 0])->results();
			$tags_array = [];

			// Tags for the post
			$enabled_tags = explode(',', $post->post_tags);
			
			if(count($ghost_tags)){
				foreach($ghost_tags as $tag){
					$tags_array[] = [
						'id' => $tag->id,
						'name' => $tag->name,
						'selected' => (in_array($tag->id, $enabled_tags))
					];
				}
			}
			
			if(Input::exists()){
				if(Token::check(Input::get('token'))){
					$validation = Validate::check($_POST, [
						'ghost_post_name' => [
							Validate::REQUIRED => true,
							Validate::MAX => 96
						],
						'ghost_post_date' => [Validate::REQUIRED => true],
						'ghost_post_content' => [Validate::REQUIRED => true]
					])->messages([
						'ghost_post_name' => [
							Validate::REQUIRED => $ghost_language->get('ghost', 'post_name_required'),
							Validate::MAX => $ghost_language->get('ghost', 'post_name_maximum')
						],
						'ghost_post_date' => $ghost_language->get('ghost', 'post_date_required'),
						'ghost_post_content' => $ghost_language->get('ghost', 'post_content_required')
					]);
								
					if($validation->passed()){


						// Image upload if image WAS empty
						if(empty($post->image)) {
							$image_upload = Ghost::uploadImage();
						}

						// Delete old image
						if(empty(Input::get('ghost_post_image'))) {
							if (str_starts_with(Output::getClean($post->image), '/uploads/ghost-')) {
								unlink(ROOT_PATH . Output::getClean($post->image));
							}	
						}

						if (is_array($image_upload) == false) { // Ensure no errors
							try {

								if(empty($post->image)) {
									$new_image = $image_upload;
								} else {
									$new_image = htmlspecialchars(Input::get('ghost_post_image'));
								}

								$post_tags_string = '';
								if (isset($_POST['ghost_post_tags']) && count($_POST['ghost_post_tags'])) {
									// Turn array of inputted forums into string of forums
									foreach ($_POST['ghost_post_tags'] as $item) {
										$post_tags_string .= $item . ',';
									}
								}
								$post_tags_string = rtrim($post_tags_string, ',');

	
								DB::getInstance()->update('ghost_posts', $post->id, [
									'name' => htmlspecialchars(Input::get('ghost_post_name')),
									'date' => htmlspecialchars(strtotime(Input::get('ghost_post_date'))),
									'readtime' => htmlspecialchars(estimated_read_time(Input::get('ghost_post_content'))),
									'image' => $new_image,
									'content' => htmlspecialchars(Input::get('ghost_post_content')),
									'post_summary' => htmlspecialchars(Input::get('ghost_post_summary')),
									'post_tags' => $post_tags_string
								]);
	
								if (!empty($post->image) && empty(htmlspecialchars(Input::get('ghost_post_image')))) {
									echo "<meta http-equiv='refresh' content='0'>";
								}  else {
									Session::flash('staff_ghost', $ghost_language->get('ghost', 'post_updated_successfully'));
									Redirect::to(URL::build('/panel/ghost'));
									die();
								}
							} catch(Exception $e){
								$errors[] = $e->getMessage();
							}
						} elseif ($image_upload != null) {
							foreach ($image_upload as $cf_error) { // Add errors to errors array
								$errors[] = $cf_error;
							}
						}
					}

					if (!empty($validation->errors())) {
					  $errors = $validation->errors();
 				    }

				} else {
					$errors[] = $language->get('general', 'invalid_token');
				}
			}
						
			$template->getEngine()->addVariables([
				'EDIT_POST' => $ghost_language->get('ghost', 'edit_post'),
				'BACK' => $language->get('general', 'back'),
				'BACK_LINK' => URL::build('/panel/ghost'),
				'GHOST_POST_NAME' => $ghost_language->get('ghost', 'ghost_post_name'),
				'GHOST_POST_DATE' => $ghost_language->get('ghost', 'ghost_post_date'),
				'GHOST_POST_IMAGE' => $ghost_language->get('ghost', 'ghost_post_image'),
				'GHOST_DELETE_IMAGE' => $ghost_language->get('ghost', 'ghost_delete_image'),
				'GHOST_POST_CONTENT' => $ghost_language->get('ghost', 'ghost_post_content'),
				'GHOST_POST_SUMMARY' => $ghost_language->get('ghost', 'ghost_post_summary'),
				'GHOST_POST_TAGS' => $ghost_language->get('ghost', 'ghost_post_tags'),
				'GHOST_POST_SUMMARY_BLANK' => $ghost_language->get('ghost', 'ghost_post_summary_blank'),
				'GHOST_POST_NAME_VALUE' => $post->name,
				'GHOST_POST_DATE_VALUE' => date("Y-m-d\Th:i", Output::getClean($post->date)),
				'GHOST_POST_IMAGE_VALUE' => Output::getClean($post->image),
				'GHOST_POST_CONTENT_VALUE' => $post->content,
				'GHOST_POST_SUMMARY_VALUE' => $post->post_summary,
				'GHOST_TAGS' => $tags_array
			]);
		
			$template_file = 'ghost/post_edit.tpl';
		break;
		case 'edit_tag':
			if(!isset($_GET['id']) || !is_numeric($_GET['id'])){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$tag = DB::getInstance()->get('ghost_tags', ['id', '=', $_GET['id']])->results();
			if(!count($tag)){
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
			$tag = $tag[0];
			
			if(Input::exists()){
				if(Token::check(Input::get('token'))){
					$validation = Validate::check($_POST, [
						'ghost_tag_name' => [
							Validate::REQUIRED => true,
							Validate::MAX => 96
						],
						'ghost_tag_color' => [Validate::REQUIRED => true]
					])->messages([
						'ghost_tag_name' => [
							Validate::REQUIRED => $ghost_language->get('ghost', 'tag_name_required'),
							Validate::MAX => $ghost_language->get('ghost', 'tag_name_maximum')
						],
						'ghost_tag_color' => $ghost_language->get('ghost', 'tag_color_required')
					]);
								
					if($validation->passed()){

							try {
								DB::getInstance()->update('ghost_tags', $tag->id, [
									'name' => htmlspecialchars(Input::get('ghost_tag_name')),
									'color' => htmlspecialchars(Input::get('ghost_tag_color'))
								]);

								Session::flash('staff_ghost', $ghost_language->get('ghost', 'tag_updated_successfully'));
								Redirect::to(URL::build('/panel/ghost'));
								die();
							} catch(Exception $e){
								$errors[] = $e->getMessage();
							}
					}

					if (!empty($validation->errors())) {
					  $errors = $validation->errors();
 				    }

				} else {
					$errors[] = $language->get('general', 'invalid_token');
				}
			}
						
			$template->getEngine()->addVariables([
				'EDIT_TAG' => $ghost_language->get('ghost', 'edit_tag'),
				'BACK' => $language->get('general', 'back'),
				'BACK_LINK' => URL::build('/panel/ghost'),
				'GHOST_TAG_NAME' => $ghost_language->get('ghost', 'ghost_tag_name'),
				'GHOST_TAG_COLOR' => $ghost_language->get('ghost', 'ghost_tag_color'),
				'GHOST_TAG_NAME_VALUE' => $tag->name,
				'GHOST_TAG_COLOR_VALUE' => $tag->color
			]);
		
			$template_file = 'ghost/tag_edit.tpl';
		break;
		case 'delete':
			if(isset($_GET['id']) && is_numeric($_GET['id'])){

				$post_delete = DB::getInstance()->get('ghost_posts', ['id', '=', $_GET['id']])->results();
				$post_delete = $post_delete[0];

				// check for old external urls and delete image
				if (str_starts_with(Output::getClean($post_delete->image), '/uploads/ghost-')) {
					unlink(ROOT_PATH . Output::getClean($post_delete->image));
				}	

				// delete post
				try {
					DB::getInstance()->delete('ghost_posts', ['id', '=', $_GET['id']]);
				} catch(Exception $e){
					die($e->getMessage());
				}

				Session::flash('staff_ghost', $ghost_language->get('ghost', 'post_deleted_successfully'));
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
		break;
		case 'delete_tag':
			if(isset($_GET['id']) && is_numeric($_GET['id'])){

				// delete tag
				try {
					DB::getInstance()->delete('ghost_tags', ['id', '=', $_GET['id']]);
				} catch(Exception $e){
					die($e->getMessage());
				}

				Session::flash('staff_ghost', $ghost_language->get('ghost', 'tag_deleted_successfully'));
				Redirect::to(URL::build('/panel/ghost'));
				die();
			}
		break;
		default:
			Redirect::to(URL::build('/panel/ghost'));
			die();
		break;
	}
}
			
Module::loadPage($user, $pages, $cache, $smarty, [$navigation, $cc_nav, $staffcp_nav], $widgets, $template);

if(Session::exists('staff_ghost'))
	$success = Session::flash('staff_ghost');

if(isset($success))
	$template->getEngine()->addVariables([
		'SUCCESS' => $success,
		'SUCCESS_TITLE' => $language->get('general', 'success')
	]);

if(isset($errors) && count($errors))
	$template->getEngine()->addVariables([
		'ERRORS' => $errors,
		'ERRORS_TITLE' => $language->get('general', 'error')
	]);

$template->getEngine()->addVariables([
	'PARENT_PAGE' => PARENT_PAGE,
	'PAGE' => PANEL_PAGE,
	'DASHBOARD' => $language->get('admin', 'dashboard'),
	'GHOST' => $ghost_language->get('ghost', 'ghost'),
	'TOKEN' => Token::get(),
	'SUBMIT' => $language->get('general', 'submit')
]);

$template->onPageLoad();

require(ROOT_PATH . '/core/templates/panel_navbar.php');

$template->displayTemplate($template_file);